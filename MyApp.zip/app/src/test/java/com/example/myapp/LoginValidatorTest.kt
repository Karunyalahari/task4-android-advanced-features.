
package com.example.myapp

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LoginValidatorTest {
    @Test
    fun email_isValid() {
        val email = "test@example.com"
        assertTrue(email.contains("@") && email.contains("."))
    }

    @Test
    fun password_tooShort_isInvalid() {
        val password = "123"
        assertFalse(password.length >= 6)
    }
}
