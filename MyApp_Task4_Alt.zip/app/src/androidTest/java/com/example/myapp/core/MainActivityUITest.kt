
package com.example.myapp.core

import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.rules.ActivityScenarioRule
import org.junit.Rule
import org.junit.Test
import com.example.myapp.R

class MainActivityUITest {
    @get:Rule
    val activityRule = ActivityScenarioRule(MainActivity::class.java)

    @Test
    fun welcomeText_isDisplayed() {
        androidx.test.espresso.Espresso.onView(withId(R.id.welcomeText)).check(matches(isDisplayed()))
    }
}
