
package com.example.myapp.features.authentication

import com.google.firebase.auth.FirebaseAuth

class AuthManager(private val auth: FirebaseAuth) {
    fun login(email: String, password: String, onSuccess: () -> Unit, onFailure: () -> Unit) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { onFailure() }
    }
}
